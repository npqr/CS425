#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <main_zip_file>"
    exit 1
fi

MAIN_ZIP="$1"
WORK_DIR="unzipped_main"
RESULTS_DIR="Results"
mkdir -p "$WORK_DIR" "$RESULTS_DIR"

# Unzip top-level zip
unzip -q "$MAIN_ZIP" -d "$WORK_DIR"

# Function to run grading on extracted client
grade_client_cpp() {
    CLIENT_FILE="$1"
    ZIP_NAME="$2"
    RESULT_FILE="$RESULTS_DIR/${ZIP_NAME%.zip}.log"

    bash autograde_multi.sh "$CLIENT_FILE" "$RESULT_FILE"
}

# Loop through each inner zip file
find "$WORK_DIR" -type f -name "*.zip" | while read INNER_ZIP; do
    ZIP_BASENAME=$(basename "$INNER_ZIP")
    TEMP_DIR=$(mktemp -d)

    unzip -q "$INNER_ZIP" -d "$TEMP_DIR"

    CLIENT_CPP=$(find "$TEMP_DIR" -name "client.cpp" | head -n 1)

    if [ -n "$CLIENT_CPP" ]; then
        grade_client_cpp "$CLIENT_CPP" "$ZIP_BASENAME"
    else
        echo "[✗] client.cpp not found in $ZIP_BASENAME" > "$RESULTS_DIR/${ZIP_BASENAME%.zip}.log"
    fi

    rm -rf "$TEMP_DIR"
done

echo "[✓] All grading completed. Results stored in $RESULTS_DIR"

