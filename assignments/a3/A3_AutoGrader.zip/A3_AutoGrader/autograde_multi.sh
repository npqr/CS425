#!/bin/bash

CLIENT_CPP="$1"
RESULT_LOG="$2"
SUDO_PASSWORD=""  # Replace or prompt securely

TMUX_SESSION="autograde_session"
SERVERS=("server.cpp" "server2.cpp" "server3.cpp")

if [ ! -f "$CLIENT_CPP" ]; then
    echo "[✗] Client file $CLIENT_CPP not found!" >> "$RESULT_LOG"
    exit 1
fi

# Compile client
g++ "$CLIENT_CPP" -o client 2>> "$RESULT_LOG"
if [ $? -ne 0 ]; then
    echo "[✗] Failed to compile $CLIENT_CPP" >> "$RESULT_LOG"
    exit 1
fi

for SERVER_SRC in "${SERVERS[@]}"; do
    SERVER_NAME=$(basename "$SERVER_SRC" .cpp)
    SERVER_BIN="./$SERVER_NAME"
    SERVER_LOG="${SERVER_NAME}_log.txt"

    echo "[*] Testing client with $SERVER_SRC" >> "$RESULT_LOG"

    g++ "$SERVER_SRC" -o "$SERVER_BIN" 2>> "$RESULT_LOG"
    if [ $? -ne 0 ]; then
        echo "[✗] Failed to compile $SERVER_SRC" >> "$RESULT_LOG"
        continue
    fi

    tmux kill-session -t $TMUX_SESSION 2>/dev/null
    tmux new-session -d -s $TMUX_SESSION

    tmux send-keys -t $TMUX_SESSION "echo $SUDO_PASSWORD | sudo -S $SERVER_BIN | tee $SERVER_LOG" C-m
    sleep 3

    tmux split-window -h -t $TMUX_SESSION
    tmux send-keys -t $TMUX_SESSION:0.1 "echo $SUDO_PASSWORD | sudo -S ./client" C-m
    sleep 5

    tmux kill-session -t $TMUX_SESSION

    if grep -q "\[+] Received SYN from" "$SERVER_LOG" &&
       grep -q "\[+] Sent SYN-ACK" "$SERVER_LOG" &&
       grep -q "\[+] Received ACK, handshake complete." "$SERVER_LOG"; then
        echo "[✓] Handshake with $SERVER_SRC successful" >> "$RESULT_LOG"
    else
        echo "[✗] Handshake with $SERVER_SRC failed" >> "$RESULT_LOG"
        cat "$SERVER_LOG" >> "$RESULT_LOG"
        echo "------" >> "$RESULT_LOG"
    fi

    rm -f "$SERVER_LOG"
done

echo "[+] Grading complete for $CLIENT_CPP" >> "$RESULT_LOG"

