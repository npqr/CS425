git clone https://github.com/google/googletest.git 
cd googletest && mkdir -p build && cd build && cmake .. && make
